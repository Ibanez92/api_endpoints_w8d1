# Weather API

This project is a simple script that retrieves weather information for a specified city using WeatherAPI.com.

## Technolgy used

- Python 3
- `requests` library (install via `pip install requests`)

## Getting Started

1. **Clone the repository** (if applicable):
   ```bash
   git clone <repository_url>
   cd <repository_directory>

2. **Install the requests library:**

    ```bash
    pip install requests

3. **Obtain an API key from WeatherAPI.com:**

- Go to WeatherAPI.com
- Sign up for a free account.
- Once registered, go to the API key section in your account dashboard.
- Copy your API key.
4. **Set your API key in the script:**

- Open the weather_api.py file.
- Replace 'a78ad79187b54458bc1211246240507' with your actual WeatherAPI.com API key.

5. **Run the script:**

    ```bash
    python weather_api.py