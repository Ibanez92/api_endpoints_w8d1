import requests

# WeatherAPI.com API key
weather_api_key = 'a78ad79187b54458bc1211246240507'

def get_weather(city):
    try:
        # URL for the WeatherAPI.com endpoint
        url = f'http://api.weatherapi.com/v1/current.json?key={weather_api_key}&q={city}'
        
        # GET request to WeatherAPI.com
        response = requests.get(url)
        
        # If the request was successful (status code 200)
        if response.status_code == 200:
            weather_data = response.json()
            # Extracting weather information
            weather_info = {
                'city': weather_data['location']['name'],
                'temperature': weather_data['current']['temp_c'],
                'condition': weather_data['current']['condition']['text'],
                'humidity': weather_data['current']['humidity'],
                'wind_speed': weather_data['current']['wind_kph']
            }
            return weather_info
        else:
            # Error responses from WeatherAPI.com
            print(f"Error: {response.status_code} - {response.text}")
            return None
    
    except requests.exceptions.RequestException as e:
        # Connection errors or exceptions
        print(f"Error: {e}")
        return None

# Example City
city_name = 'London'
weather_info = get_weather(city_name)

if weather_info:
    print("Weather Information:")
    print(f"City: {weather_info['city']}")
    print(f"Temperature: {weather_info['temperature']}°C")
    print(f"Weather Condition: {weather_info['condition']}")
    print(f"Humidity: {weather_info['humidity']}%")
    print(f"Wind Speed: {weather_info['wind_speed']} km/h")
else:
    print("Failed to retrieve weather information.")
